// Trial Junkies Main JavaScript

document.addEventListener('DOMContentLoaded', () => {
    // Hamburger menu toggle
    const menuToggle = document.getElementById('menu-toggle');
    const navDropdown = document.getElementById('nav-dropdown');
    
    if (menuToggle && navDropdown) {
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active');
            navDropdown.classList.toggle('show');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            if (!menuToggle.contains(event.target) && !navDropdown.contains(event.target)) {
                menuToggle.classList.remove('active');
                navDropdown.classList.remove('show');
            }
        });
        
        // Close dropdown when clicking on a link
        const navLinks = navDropdown.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                menuToggle.classList.remove('active');
                navDropdown.classList.remove('show');
            });
        });
    }
    
    // Connect wallet buttons
    const ctaButtons = document.querySelectorAll('.cta-button, .plan-button');
    ctaButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Trigger wallet connection
            if (window.solana && window.solana.isPhantom) {
                // If Phantom wallet is installed, connect
                connectPhantomWallet();
            } else {
                // If not installed, show wallet dropdown with install option
                const walletBtn = document.getElementById('phantom-wallet-btn');
                if (walletBtn) {
                    walletBtn.click();
                }
            }
        });
    });
    
    // Helper function to connect Phantom wallet
    async function connectPhantomWallet() {
        try {
            if (!window.solana || !window.solana.isPhantom) {
                showNotification('Phantom wallet is not installed. Please install it first.', 'error');
                return;
            }
            
            const response = await window.solana.connect();
            window.walletConnected = true;
            window.walletAddress = response.publicKey.toString();
            
            // After connecting, redirect to subscription plans section
            window.location.href = '#subscription-plans';
            
            showNotification('Wallet connected successfully!', 'success');
        } catch (error) {
            console.error('Error connecting to Phantom wallet:', error);
            showNotification('Failed to connect wallet. Please try again.', 'error');
        }
    }
    
    // Show notification
    function showNotification(message, type = 'success') {
        // Remove any existing notifications
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            document.body.removeChild(existingNotification);
        }
        
        // Create new notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Show notification with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Hide and remove after delay
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
    
    // Horizontal scrolling for comics section
    const comicsContainer = document.querySelector('.comics-scroll-container');
    const prevComicBtn = document.querySelector('.prev-comic');
    const nextComicBtn = document.querySelector('.next-comic');
    
    if (comicsContainer && prevComicBtn && nextComicBtn) {
        // Scroll to next comic
        nextComicBtn.addEventListener('click', () => {
            comicsContainer.scrollBy({
                left: comicsContainer.offsetWidth,
                behavior: 'smooth'
            });
        });
        
        // Scroll to previous comic
        prevComicBtn.addEventListener('click', () => {
            comicsContainer.scrollBy({
                left: -comicsContainer.offsetWidth,
                behavior: 'smooth'
            });
        });
    }
});
