// Subscription Plans JavaScript
// This file handles subscription plan selection and payment processing

document.addEventListener('DOMContentLoaded', () => {
    const planButtons = document.querySelectorAll('.plan-button');
    
    planButtons.forEach(button => {
        button.addEventListener('click', () => {
            const plan = button.closest('.plan');
            const planName = plan.querySelector('h3').textContent;
            const planPrice = plan.querySelector('.plan-price').textContent;
            
            // Trigger plan selection event
            const event = new CustomEvent('plan_selected', {
                detail: {
                    plan: planName,
                    price: planPrice
                }
            });
            document.dispatchEvent(event);
            
            // Highlight selected plan
            document.querySelectorAll('.plan').forEach(p => {
                p.classList.remove('selected-plan');
            });
            plan.classList.add('selected-plan');
            
            // Trigger wallet connection if not connected
            if (!window.walletConnected) {
                window.connectPhantomWallet();
            } else {
                // If wallet is already connected, process payment directly
                if (typeof window.processPayment === 'function') {
                    window.processPayment(planName, planPrice);
                }
            }
        });
    });
    
    // Check for existing subscription
    function checkExistingSubscription() {
        const subscriptionData = localStorage.getItem('subscription');
        if (subscriptionData) {
            try {
                const subscription = JSON.parse(subscriptionData);
                const now = new Date();
                const endDate = new Date(subscription.endDate);
                
                // If subscription is still valid
                if (endDate > now) {
                    // Find and highlight the active plan
                    const planElements = document.querySelectorAll('.plan');
                    planElements.forEach(plan => {
                        const planName = plan.querySelector('h3').textContent;
                        if (planName === subscription.plan) {
                            plan.classList.add('active-plan');
                            
                            // Add active subscription indicator
                            const activeIndicator = document.createElement('div');
                            activeIndicator.className = 'active-subscription';
                            
                            const daysLeft = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
                            activeIndicator.textContent = `Active (${daysLeft} days left)`;
                            
                            const planHeader = plan.querySelector('.plan-header');
                            planHeader.appendChild(activeIndicator);
                            
                            // Change button text
                            const button = plan.querySelector('.plan-button');
                            button.textContent = 'Extend Subscription';
                        }
                    });
                    
                    // Show active subscription notification
                    if (window.showWalletNotification) {
                        window.showWalletNotification(`You have an active ${subscription.plan} subscription`, 'info');
                    }
                }
            } catch (error) {
                console.error('Error parsing subscription data:', error);
            }
        }
    }
    
    // Initialize
    checkExistingSubscription();
});
