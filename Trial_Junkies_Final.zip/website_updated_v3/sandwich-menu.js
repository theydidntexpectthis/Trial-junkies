// Sandwich Dropdown Menu JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Get menu elements
    const menuToggle = document.getElementById('menu-toggle');
    const navDropdown = document.getElementById('nav-dropdown');
    
    // Create overlay element
    const overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);
    
    // Toggle menu function
    function toggleMenu() {
        menuToggle.classList.toggle('active');
        navDropdown.classList.toggle('show');
        overlay.classList.toggle('show');
        
        // Prevent body scrolling when menu is open
        if (navDropdown.classList.contains('show')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    }
    
    // Event listeners
    menuToggle.addEventListener('click', toggleMenu);
    
    // Close menu when clicking on overlay
    overlay.addEventListener('click', toggleMenu);
    
    // Close menu when clicking on a link
    const navLinks = navDropdown.querySelectorAll('a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            toggleMenu();
            
            // Smooth scroll to section
            const targetId = this.getAttribute('href');
            if (targetId.startsWith('#') && targetId.length > 1) {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    event.preventDefault();
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Close menu on window resize (if desktop size)
    window.addEventListener('resize', function() {
        if (window.innerWidth > 992 && navDropdown.classList.contains('show')) {
            toggleMenu();
        }
    });
    
    // Add flame icons to menu items
    function addFlameIcons() {
        const menuItems = document.querySelectorAll('.nav-dropdown a');
        menuItems.forEach(item => {
            // Only add if not already present
            if (!item.querySelector('.menu-flame')) {
                const flameIcon = document.createElement('span');
                flameIcon.className = 'menu-flame';
                flameIcon.innerHTML = '🔥';
                item.prepend(flameIcon);
            }
        });
    }
    
    // Initialize
    addFlameIcons();
});
