// Bot Integration JavaScript
// This file handles the integration between the website and the Discord/Telegram bots

class BotIntegration {
    constructor() {
        this.initialized = false;
        this.subscriptionManager = window.SubscriptionManager;
    }

    // Initialize the bot integration
    async initialize() {
        try {
            if (!this.subscriptionManager) {
                console.error('Subscription Manager not found');
                return false;
            }

            // Ensure subscription manager is initialized
            if (!this.subscriptionManager.initialized) {
                await this.subscriptionManager.initialize();
            }

            this.initialized = true;
            console.log('Bot Integration initialized');
            
            // Set up event listeners for bot-related events
            this.setupEventListeners();
            
            return true;
        } catch (error) {
            console.error('Failed to initialize Bot Integration:', error);
            return false;
        }
    }

    // Set up event listeners
    setupEventListeners() {
        // Listen for subscription activation events
        document.addEventListener('subscription_activated', (event) => {
            this.notifyBots('subscription_activated', event.detail);
        });

        // Listen for wallet connection events
        document.addEventListener('wallet_connected', (event) => {
            this.notifyBots('wallet_connected', event.detail);
        });

        // Listen for wallet disconnection events
        document.addEventListener('wallet_disconnected', () => {
            this.notifyBots('wallet_disconnected', {});
        });
    }

    // Verify if a user can use bot commands
    async verifyBotAccess(walletAddress, commandType) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Verify subscription
            const subscriptionStatus = await this.subscriptionManager.verifySubscription(walletAddress);
            
            if (!subscriptionStatus.active) {
                return {
                    allowed: false,
                    message: 'You need an active subscription to use this command. Visit our website to subscribe.'
                };
            }
            
            // Check command type against subscription plan
            const plan = subscriptionStatus.plan;
            
            // Define command access by plan
            const commandAccess = {
                'Casual User': ['hit'],
                'Trial Junkie': ['hit', 'binge'],
                'Overdose Mode': ['hit', 'binge', 'overload', 'overdose_mode']
            };
            
            // Check if the user's plan allows this command
            if (commandAccess[plan] && commandAccess[plan].includes(commandType)) {
                return {
                    allowed: true,
                    plan: plan,
                    message: 'Command access granted'
                };
            } else {
                return {
                    allowed: false,
                    plan: plan,
                    message: `Your current plan (${plan}) does not include access to this command. Please upgrade your subscription.`
                };
            }
            
        } catch (error) {
            console.error('Error verifying bot access:', error);
            return {
                allowed: false,
                error: true,
                message: 'Error verifying access'
            };
        }
    }

    // Track command usage
    async trackCommandUsage(walletAddress, commandType, result) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Get current usage data
            const usageKey = 'command_usage_' + walletAddress;
            let usageData = localStorage.getItem(usageKey);
            
            if (usageData) {
                usageData = JSON.parse(usageData);
            } else {
                usageData = {
                    walletAddress,
                    commands: {},
                    totalUsage: 0
                };
            }
            
            // Update usage data
            if (!usageData.commands[commandType]) {
                usageData.commands[commandType] = {
                    count: 0,
                    successes: 0,
                    failures: 0,
                    lastUsed: null
                };
            }
            
            usageData.commands[commandType].count++;
            usageData.totalUsage++;
            usageData.commands[commandType].lastUsed = new Date().toISOString();
            
            if (result.success) {
                usageData.commands[commandType].successes++;
            } else {
                usageData.commands[commandType].failures++;
            }
            
            // Save updated usage data
            localStorage.setItem(usageKey, JSON.stringify(usageData));
            
            return {
                success: true,
                usageData
            };
        } catch (error) {
            console.error('Error tracking command usage:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Notify bots of events
    notifyBots(eventType, data) {
        // In a real implementation, this would send data to the bot servers
        console.log(`Bot notification: ${eventType}`, data);
        
        // For demo purposes, we'll just store the event in localStorage
        try {
            const eventsKey = 'bot_events';
            let events = localStorage.getItem(eventsKey);
            
            if (events) {
                events = JSON.parse(events);
            } else {
                events = [];
            }
            
            events.push({
                type: eventType,
                data: data,
                timestamp: new Date().toISOString()
            });
            
            // Keep only the last 100 events
            if (events.length > 100) {
                events = events.slice(-100);
            }
            
            localStorage.setItem(eventsKey, JSON.stringify(events));
            
            return true;
        } catch (error) {
            console.error('Error notifying bots:', error);
            return false;
        }
    }

    // Get command usage statistics
    async getCommandStats(walletAddress) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Get usage data
            const usageKey = 'command_usage_' + walletAddress;
            const usageData = localStorage.getItem(usageKey);
            
            if (!usageData) {
                return {
                    success: true,
                    stats: {
                        totalCommands: 0,
                        commandBreakdown: {}
                    }
                };
            }
            
            const usage = JSON.parse(usageData);
            
            // Calculate statistics
            const stats = {
                totalCommands: usage.totalUsage,
                commandBreakdown: {}
            };
            
            for (const [command, data] of Object.entries(usage.commands)) {
                stats.commandBreakdown[command] = {
                    count: data.count,
                    successRate: data.count > 0 ? (data.successes / data.count) * 100 : 0,
                    lastUsed: data.lastUsed
                };
            }
            
            return {
                success: true,
                stats
            };
        } catch (error) {
            console.error('Error getting command stats:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

// Export the bot integration
window.BotIntegration = new BotIntegration();

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.BotIntegration.initialize();
});
