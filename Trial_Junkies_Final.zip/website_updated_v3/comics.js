// Comics Section with Horizontal Scrolling
// This script handles the comics section functionality

document.addEventListener('DOMContentLoaded', () => {
    // Comic strip data
    const comicStrips = [
        {
            title: "The Addiction Begins",
            panels: [
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "Why pay for subscriptions when you can get them for free?",
                    caption: "Heroin Harry discovers the power of free trials"
                },
                {
                    image: "assets/flaming-skull.png",
                    dialogue: "Just one more free trial... I can stop anytime I want!",
                    caption: "The addiction begins"
                },
                {
                    image: "assets/skeleton-green.png",
                    dialogue: "You're saving HOW MUCH per month?!",
                    caption: "Friends notice the savings"
                },
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "I need more... MORE FREE TRIALS!",
                    caption: "Harry becomes obsessed with savings"
                }
            ]
        },
        {
            title: "The Intervention",
            panels: [
                {
                    image: "assets/flaming-skull.png",
                    dialogue: "Harry, we need to talk about your free trial habit...",
                    caption: "The team confronts Harry"
                },
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "I can stop whenever I want! I just saved $1,620 last year!",
                    caption: "Harry defends his addiction"
                },
                {
                    image: "assets/skeleton-green.png",
                    dialogue: "But you're spending all your time managing trials!",
                    caption: "The team points out the problem"
                },
                {
                    image: "assets/flaming-skull.png",
                    dialogue: "What if we automated the whole process?",
                    caption: "A solution emerges"
                }
            ]
        },
        {
            title: "The Withdrawal",
            panels: [
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "NO! My Netflix trial expired! I need my fix!",
                    caption: "Harry experiences withdrawal"
                },
                {
                    image: "assets/skeleton-green.png",
                    dialogue: "Calm down! We can generate a new one in seconds.",
                    caption: "Molly Morphine offers help"
                },
                {
                    image: "assets/flaming-skull.png",
                    dialogue: "Just one click and you'll have a fresh account.",
                    caption: "Vape Vince demonstrates the solution"
                },
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "Ahhh... that's the good stuff. Free trials forever!",
                    caption: "Harry gets his fix"
                }
            ]
        },
        {
            title: "The Savings Calculator",
            panels: [
                {
                    image: "assets/skeleton-green.png",
                    dialogue: "Let me show you how much you can save with Trial Junkies.",
                    caption: "Keta Kev explains the savings"
                },
                {
                    image: "assets/flaming-skull.png",
                    dialogue: "$600/year on streaming alone? That's insane!",
                    caption: "The numbers are shocking"
                },
                {
                    image: "assets/skeleton-smoking.png",
                    dialogue: "Add another $300 for software subscriptions!",
                    caption: "The savings keep adding up"
                },
                {
                    image: "assets/skeleton-green.png",
                    dialogue: "Total savings: $1,620 per year. Ready to get hooked?",
                    caption: "The final calculation"
                }
            ]
        }
    ];

    // Create comic strips
    function createComicStrips() {
        const comicsContainer = document.querySelector('.comics-container');
        if (!comicsContainer) return;

        // Clear existing content
        comicsContainer.innerHTML = '';

        // Create comic strips
        comicStrips.forEach(comic => {
            const comicStrip = document.createElement('div');
            comicStrip.className = 'comic-strip';

            const comicTitle = document.createElement('h3');
            comicTitle.className = 'comic-title';
            comicTitle.textContent = comic.title;

            const comicPanels = document.createElement('div');
            comicPanels.className = 'comic-panels';

            // Create panels
            comic.panels.forEach(panel => {
                const comicPanel = document.createElement('div');
                comicPanel.className = 'comic-panel';

                // Use placeholder image if available, otherwise use skeleton image
                const panelImage = document.createElement('img');
                panelImage.className = 'panel-image';
                panelImage.src = panel.image || 'assets/skeleton-smoking.png';
                panelImage.alt = 'Comic Panel';

                const panelContent = document.createElement('div');
                panelContent.className = 'panel-content';

                const panelDialogue = document.createElement('div');
                panelDialogue.className = 'panel-dialogue';
                panelDialogue.textContent = panel.dialogue;

                const panelCaption = document.createElement('div');
                panelCaption.className = 'panel-caption';
                panelCaption.textContent = panel.caption;

                panelContent.appendChild(panelDialogue);
                panelContent.appendChild(panelCaption);

                comicPanel.appendChild(panelImage);
                comicPanel.appendChild(panelContent);

                comicPanels.appendChild(comicPanel);
            });

            comicStrip.appendChild(comicTitle);
            comicStrip.appendChild(comicPanels);

            comicsContainer.appendChild(comicStrip);
        });

        // Add navigation buttons
        const comicsNavigation = document.createElement('div');
        comicsNavigation.className = 'comics-navigation';

        const prevButton = document.createElement('button');
        prevButton.className = 'comics-scroll-btn prev';
        prevButton.innerHTML = '<i class="fas fa-chevron-left"></i> Previous';
        prevButton.addEventListener('click', () => {
            comicsContainer.scrollBy({
                left: -400,
                behavior: 'smooth'
            });
        });

        const nextButton = document.createElement('button');
        nextButton.className = 'comics-scroll-btn next';
        nextButton.innerHTML = 'Next <i class="fas fa-chevron-right"></i>';
        nextButton.addEventListener('click', () => {
            comicsContainer.scrollBy({
                left: 400,
                behavior: 'smooth'
            });
        });

        comicsNavigation.appendChild(prevButton);
        comicsNavigation.appendChild(nextButton);

        // Add navigation after the container
        const comicsSection = document.querySelector('.comics-section');
        if (comicsSection) {
            comicsSection.appendChild(comicsNavigation);
        }
    }

    // Initialize comics section
    createComicStrips();

    // Add keyboard navigation for desktop
    document.addEventListener('keydown', (e) => {
        const comicsContainer = document.querySelector('.comics-container');
        if (!comicsContainer) return;

        // Check if comics section is in viewport
        const rect = comicsContainer.getBoundingClientRect();
        const isVisible = (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );

        if (!isVisible) return;

        // Left arrow key
        if (e.key === 'ArrowLeft') {
            comicsContainer.scrollBy({
                left: -400,
                behavior: 'smooth'
            });
        }
        // Right arrow key
        else if (e.key === 'ArrowRight') {
            comicsContainer.scrollBy({
                left: 400,
                behavior: 'smooth'
            });
        }
    });

    // Add touch swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;

    const comicsContainer = document.querySelector('.comics-container');
    if (comicsContainer) {
        comicsContainer.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, false);

        comicsContainer.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, false);
    }

    function handleSwipe() {
        if (!comicsContainer) return;

        const swipeThreshold = 50;
        if (touchEndX < touchStartX - swipeThreshold) {
            // Swipe left
            comicsContainer.scrollBy({
                left: 400,
                behavior: 'smooth'
            });
        }
        if (touchEndX > touchStartX + swipeThreshold) {
            // Swipe right
            comicsContainer.scrollBy({
                left: -400,
                behavior: 'smooth'
            });
        }
    }
});
