// Updated Phantom Wallet Button JavaScript
// This script handles the responsive wallet button and dropdown menu functionality

document.addEventListener('DOMContentLoaded', () => {
    // Create wallet button and dropdown elements
    function createWalletElements() {
        // Create the official Phantom wallet button
        const walletBtn = document.createElement('div');
        walletBtn.className = 'phantom-button';
        walletBtn.id = 'phantom-wallet-btn';
        
        const walletImg = document.createElement('img');
        walletImg.src = 'assets/phantom-logo.png';
        walletImg.alt = 'Phantom Wallet';
        
        const walletText = document.createElement('span');
        walletText.id = 'wallet-btn-text';
        walletText.textContent = 'Connect Wallet';
        
        walletBtn.appendChild(walletImg);
        walletBtn.appendChild(walletText);
        
        // Create the wallet dropdown
        const walletDropdown = document.createElement('div');
        walletDropdown.className = 'wallet-dropdown';
        walletDropdown.id = 'wallet-dropdown';
        
        // Add the button and dropdown to the document
        document.body.appendChild(walletBtn);
        document.body.appendChild(walletDropdown);
        
        // Add event listeners
        walletBtn.addEventListener('click', toggleWalletDropdown);
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            const dropdown = document.getElementById('wallet-dropdown');
            const button = document.getElementById('phantom-wallet-btn');
            
            if (dropdown && button && 
                !dropdown.contains(event.target) && 
                !button.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
    }
    
    // Toggle wallet dropdown visibility
    function toggleWalletDropdown() {
        const dropdown = document.getElementById('wallet-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('show');
            
            // If showing dropdown, populate it with content
            if (dropdown.classList.contains('show')) {
                populateWalletDropdown();
            }
        }
    }
    
    // Populate wallet dropdown with content based on connection status
    function populateWalletDropdown() {
        const dropdown = document.getElementById('wallet-dropdown');
        if (!dropdown) return;
        
        // Clear existing content
        dropdown.innerHTML = '';
        
        // Check if wallet is connected
        if (window.walletConnected) {
            // Connected state content
            const walletAddress = document.createElement('div');
            walletAddress.className = 'wallet-address';
            walletAddress.textContent = formatAddress(window.walletAddress || '');
            
            const walletBalance = document.createElement('div');
            walletBalance.className = 'wallet-balance';
            walletBalance.textContent = `${window.walletBalance || '0'} SOL`;
            
            const divider = document.createElement('div');
            divider.className = 'wallet-dropdown-divider';
            
            const viewTransactions = document.createElement('a');
            viewTransactions.className = 'wallet-dropdown-item';
            viewTransactions.href = `https://explorer.solana.com/address/${window.walletAddress}`;
            viewTransactions.target = '_blank';
            viewTransactions.textContent = 'View Transactions';
            
            const copyAddress = document.createElement('a');
            copyAddress.className = 'wallet-dropdown-item';
            copyAddress.href = '#';
            copyAddress.textContent = 'Copy Address';
            copyAddress.addEventListener('click', (e) => {
                e.preventDefault();
                navigator.clipboard.writeText(window.walletAddress || '');
                showNotification('Address copied to clipboard!', 'success');
            });
            
            const disconnectWallet = document.createElement('a');
            disconnectWallet.className = 'wallet-dropdown-item';
            disconnectWallet.href = '#';
            disconnectWallet.textContent = 'Disconnect Wallet';
            disconnectWallet.addEventListener('click', (e) => {
                e.preventDefault();
                disconnectPhantomWallet();
            });
            
            dropdown.appendChild(walletAddress);
            dropdown.appendChild(walletBalance);
            dropdown.appendChild(divider);
            dropdown.appendChild(viewTransactions);
            dropdown.appendChild(copyAddress);
            dropdown.appendChild(disconnectWallet);
        } else {
            // Not connected state content
            const connectPhantom = document.createElement('a');
            connectPhantom.className = 'wallet-dropdown-item';
            connectPhantom.href = '#';
            connectPhantom.innerHTML = '<img src="assets/phantom-logo.png" alt="Phantom"> Connect Phantom';
            connectPhantom.addEventListener('click', (e) => {
                e.preventDefault();
                connectPhantomWallet();
            });
            
            const getPhantom = document.createElement('a');
            getPhantom.className = 'wallet-dropdown-item';
            getPhantom.href = 'https://phantom.app/';
            getPhantom.target = '_blank';
            getPhantom.textContent = 'Get Phantom Wallet';
            
            dropdown.appendChild(connectPhantom);
            dropdown.appendChild(getPhantom);
        }
    }
    
    // Format wallet address for display (truncate middle)
    function formatAddress(address) {
        if (!address || address.length < 10) return address;
        return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    }
    
    // Show notification
    function showNotification(message, type = 'success') {
        // Remove any existing notifications
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            document.body.removeChild(existingNotification);
        }
        
        // Create new notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Show notification with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Hide and remove after delay
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
    
    // Connect to Phantom wallet
    async function connectPhantomWallet() {
        try {
            // Check if Phantom is installed
            if (!window.solana || !window.solana.isPhantom) {
                showNotification('Phantom wallet is not installed. Please install it first.', 'error');
                return;
            }
            
            // Connect to wallet
            const response = await window.solana.connect();
            window.walletConnected = true;
            window.walletAddress = response.publicKey.toString();
            
            // Update button text
            const walletBtnText = document.getElementById('wallet-btn-text');
            if (walletBtnText) {
                walletBtnText.textContent = 'Connected';
            }
            
            // Get wallet balance
            try {
                const connection = new solanaWeb3.Connection('https://api.mainnet-beta.solana.com');
                const balance = await connection.getBalance(response.publicKey);
                window.walletBalance = (balance / 1000000000).toFixed(2); // Convert lamports to SOL
            } catch (error) {
                console.error('Error getting balance:', error);
                window.walletBalance = '?';
            }
            
            // Update dropdown content
            populateWalletDropdown();
            
            showNotification('Wallet connected successfully!', 'success');
            
            // Save connection state
            localStorage.setItem('walletConnected', 'true');
            localStorage.setItem('walletAddress', window.walletAddress);
            
            // Redirect to subscription plans section
            window.location.href = '#subscription-plans';
            
            // Trigger subscription selection event
            const event = new CustomEvent('wallet_connected', {
                detail: {
                    address: window.walletAddress
                }
            });
            document.dispatchEvent(event);
            
        } catch (error) {
            console.error('Error connecting to Phantom wallet:', error);
            showNotification('Failed to connect wallet. Please try again.', 'error');
        }
    }
    
    // Disconnect from Phantom wallet
    function disconnectPhantomWallet() {
        try {
            if (window.solana && window.solana.isPhantom) {
                window.solana.disconnect();
            }
            
            window.walletConnected = false;
            window.walletAddress = null;
            window.walletBalance = null;
            
            // Update button text
            const walletBtnText = document.getElementById('wallet-btn-text');
            if (walletBtnText) {
                walletBtnText.textContent = 'Connect Wallet';
            }
            
            // Update dropdown content
            populateWalletDropdown();
            
            // Close dropdown
            const dropdown = document.getElementById('wallet-dropdown');
            if (dropdown) {
                dropdown.classList.remove('show');
            }
            
            showNotification('Wallet disconnected', 'success');
            
            // Clear saved connection state
            localStorage.removeItem('walletConnected');
            localStorage.removeItem('walletAddress');
            
            // Trigger wallet disconnected event
            const event = new CustomEvent('wallet_disconnected');
            document.dispatchEvent(event);
            
        } catch (error) {
            console.error('Error disconnecting from Phantom wallet:', error);
            showNotification('Failed to disconnect wallet', 'error');
        }
    }
    
    // Check for saved wallet connection
    function checkSavedWalletConnection() {
        const savedConnected = localStorage.getItem('walletConnected');
        const savedAddress = localStorage.getItem('walletAddress');
        
        if (savedConnected === 'true' && savedAddress) {
            window.walletConnected = true;
            window.walletAddress = savedAddress;
            
            // Update button text
            const walletBtnText = document.getElementById('wallet-btn-text');
            if (walletBtnText) {
                walletBtnText.textContent = 'Connected';
            }
            
            // Try to reconnect to get current balance
            if (window.solana && window.solana.isPhantom && window.solana.isConnected) {
                try {
                    const connection = new solanaWeb3.Connection('https://api.mainnet-beta.solana.com');
                    connection.getBalance(new solanaWeb3.PublicKey(savedAddress))
                        .then(balance => {
                            window.walletBalance = (balance / 1000000000).toFixed(2);
                        })
                        .catch(error => {
                            console.error('Error getting balance:', error);
                            window.walletBalance = '?';
                        });
                } catch (error) {
                    console.error('Error reconnecting to wallet:', error);
                }
            }
        }
    }
    
    // Adjust wallet button position based on screen size
    function adjustWalletButtonPosition() {
        const walletBtn = document.getElementById('phantom-wallet-btn');
        if (!walletBtn) return;
        
        // Check if mobile view
        if (window.innerWidth <= 767) {
            // Position next to hamburger menu
            walletBtn.style.right = '80px';
            walletBtn.style.top = '15px';
        } else if (window.innerWidth <= 1199) {
            // Tablet view
            walletBtn.style.right = '120px';
            walletBtn.style.top = '18px';
        } else {
            // Desktop view
            walletBtn.style.right = '120px';
            walletBtn.style.top = '20px';
        }
    }
    
    // Initialize wallet functionality
    function initWallet() {
        createWalletElements();
        checkSavedWalletConnection();
        adjustWalletButtonPosition();
        
        // Listen for window resize to adjust button position
        window.addEventListener('resize', adjustWalletButtonPosition);
        
        // Listen for plan selection events
        document.addEventListener('plan_selected', (event) => {
            if (!window.walletConnected) {
                connectPhantomWallet();
            } else {
                processPayment(event.detail.plan, event.detail.price);
            }
        });
    }
    
    // Process payment for subscription
    async function processPayment(plan, price) {
        if (!window.walletConnected) {
            showNotification('Please connect your wallet first', 'error');
            return;
        }
        
        showNotification(`Processing payment for ${plan} plan...`, 'info');
        
        try {
            // This would be replaced with actual Solana transaction code
            // For now, we'll simulate a successful payment
            
            setTimeout(() => {
                showNotification(`Successfully subscribed to ${plan} plan!`, 'success');
                
                // Save subscription data
                const subscriptionData = {
                    plan: plan,
                    price: price,
                    startDate: new Date().toISOString(),
                    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
                    walletAddress: window.walletAddress
                };
                
                localStorage.setItem('subscription', JSON.stringify(subscriptionData));
                
                // Trigger subscription event for backend tracking
                const event = new CustomEvent('subscription_activated', {
                    detail: subscriptionData
                });
                document.dispatchEvent(event);
                
            }, 2000);
            
        } catch (error) {
            console.error('Payment processing error:', error);
            showNotification('Payment failed. Please try again.', 'error');
        }
    }
    
    // Initialize when DOM is loaded
    initWallet();
    
    // Make functions available globally
    window.connectPhantomWallet = connectPhantomWallet;
    window.disconnectPhantomWallet = disconnectPhantomWallet;
    window.showWalletNotification = showNotification;
});
