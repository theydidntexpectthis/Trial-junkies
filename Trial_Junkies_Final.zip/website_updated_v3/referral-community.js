// Referral System and Community Integration
// This script handles the referral system and community integration functionality

document.addEventListener('DOMContentLoaded', () => {
    // Generate a unique referral code for the user
    function generateReferralCode() {
        // Check if user already has a referral code stored
        let referralCode = localStorage.getItem('trialJunkiesReferralCode');
        
        if (!referralCode) {
            // Generate a new code if none exists
            const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed similar looking characters
            let result = 'TJ-';
            for (let i = 0; i < 8; i++) {
                result += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            referralCode = result;
            
            // Store the code
            localStorage.setItem('trialJunkiesReferralCode', referralCode);
        }
        
        return referralCode;
    }
    
    // Initialize referral code display
    function initializeReferralCode() {
        const referralCodeElement = document.getElementById('referral-code');
        if (referralCodeElement) {
            referralCodeElement.value = generateReferralCode();
        }
    }
    
    // Copy referral code to clipboard
    function setupCopyButton() {
        const copyButton = document.getElementById('copy-referral-code');
        if (copyButton) {
            copyButton.addEventListener('click', () => {
                const referralCode = document.getElementById('referral-code');
                if (referralCode) {
                    referralCode.select();
                    document.execCommand('copy');
                    
                    // Show success message
                    copyButton.textContent = 'Copied!';
                    setTimeout(() => {
                        copyButton.textContent = 'Copy';
                    }, 2000);
                }
            });
        }
    }
    
    // Track referral stats
    function loadReferralStats() {
        // In a real implementation, these would be fetched from a server
        // For now, we'll use placeholder data or localStorage
        
        let referrals = parseInt(localStorage.getItem('trialJunkiesReferrals') || '0');
        let earnings = parseFloat(localStorage.getItem('trialJunkiesEarnings') || '0');
        
        // Display stats
        const referralsElement = document.getElementById('referrals-count');
        const earningsElement = document.getElementById('earnings-count');
        
        if (referralsElement) {
            referralsElement.textContent = referrals;
        }
        
        if (earningsElement) {
            earningsElement.textContent = earnings.toFixed(2);
        }
    }
    
    // Create referral link with user's code
    function createReferralLinks() {
        const referralCode = generateReferralCode();
        const referralLinks = document.querySelectorAll('.referral-link');
        
        referralLinks.forEach(link => {
            const baseUrl = link.getAttribute('data-base-url') || window.location.origin;
            link.href = `${baseUrl}?ref=${referralCode}`;
        });
    }
    
    // Check for incoming referral code
    function checkIncomingReferral() {
        const urlParams = new URLSearchParams(window.location.search);
        const referralCode = urlParams.get('ref');
        
        if (referralCode && !localStorage.getItem('trialJunkiesReferredBy')) {
            // Store the referrer code
            localStorage.setItem('trialJunkiesReferredBy', referralCode);
            
            // Show a thank you message
            const referralThanks = document.createElement('div');
            referralThanks.className = 'wallet-notification success';
            referralThanks.textContent = `Welcome! You were referred by ${referralCode}`;
            
            document.body.appendChild(referralThanks);
            
            setTimeout(() => {
                referralThanks.classList.add('show');
            }, 10);
            
            setTimeout(() => {
                referralThanks.classList.remove('show');
                setTimeout(() => {
                    document.body.removeChild(referralThanks);
                }, 300);
            }, 5000);
        }
    }
    
    // Create Discord invite link
    function createDiscordInvite() {
        const discordButton = document.getElementById('join-discord');
        if (discordButton) {
            const referralCode = generateReferralCode();
            discordButton.href = `https://discord.gg/trialjunkies?ref=${referralCode}`;
        }
    }
    
    // Create Telegram invite link
    function createTelegramInvite() {
        const telegramButton = document.getElementById('join-telegram');
        if (telegramButton) {
            const referralCode = generateReferralCode();
            telegramButton.href = `https://t.me/trialjunkiesbot?start=${referralCode}`;
        }
    }
    
    // Initialize community owner referral section
    function initializeCommunityOwnerSection() {
        const communityOwnerButton = document.getElementById('become-community-owner');
        if (communityOwnerButton) {
            communityOwnerButton.addEventListener('click', () => {
                // In a real implementation, this would open a modal or redirect to a form
                // For now, we'll just show a notification
                
                const notification = document.createElement('div');
                notification.className = 'wallet-notification success';
                notification.textContent = 'Please connect your wallet first to become a community owner';
                
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.classList.add('show');
                }, 10);
                
                setTimeout(() => {
                    notification.classList.remove('show');
                    setTimeout(() => {
                        document.body.removeChild(notification);
                    }, 300);
                }, 5000);
                
                // If wallet is connected, we would show the community owner form
                if (window.walletConnected) {
                    // Show community owner form
                    // This would be implemented in a real application
                }
            });
        }
    }
    
    // Initialize all referral and community functionality
    function initializeReferralSystem() {
        initializeReferralCode();
        setupCopyButton();
        loadReferralStats();
        createReferralLinks();
        checkIncomingReferral();
        createDiscordInvite();
        createTelegramInvite();
        initializeCommunityOwnerSection();
    }
    
    // Initialize when DOM is loaded
    initializeReferralSystem();
});
