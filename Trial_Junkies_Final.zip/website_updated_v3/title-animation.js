// Title Animation JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Function to split text into individual characters for animation
    function splitTextIntoChars(element) {
        const text = element.textContent;
        element.textContent = '';
        element.classList.add('animated-title');
        
        // Add flame elements
        const flame1 = document.createElement('span');
        flame1.className = 'flame-1';
        flame1.textContent = '🔥';
        element.appendChild(flame1);
        
        const flame2 = document.createElement('span');
        flame2.className = 'flame-2';
        flame2.textContent = '🔥';
        element.appendChild(flame2);
        
        const flame3 = document.createElement('span');
        flame3.className = 'flame-3';
        flame3.textContent = '🔥';
        element.appendChild(flame3);
        
        // Split text into characters
        for (let i = 0; i < text.length; i++) {
            const char = document.createElement('span');
            char.className = 'char';
            char.textContent = text[i];
            char.style.setProperty('--char-index', i);
            element.appendChild(char);
        }
        
        // Add 3D effect to hero title
        if (element.closest('.hero-content')) {
            element.classList.add('three-d');
        }
    }
    
    // Apply to all title elements
    const titleElements = document.querySelectorAll('.logo h1, .hero-content h1');
    titleElements.forEach(splitTextIntoChars);
    
    // Add scroll-triggered animations
    function handleScrollAnimations() {
        const animatedTitles = document.querySelectorAll('.animated-title');
        
        animatedTitles.forEach(title => {
            const titlePosition = title.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (titlePosition < screenPosition) {
                title.style.visibility = 'visible';
                title.classList.add('animate');
            }
        });
    }
    
    // Initial check and scroll listener
    handleScrollAnimations();
    window.addEventListener('scroll', handleScrollAnimations);
    
    // Add interactive hover effects
    const heroTitle = document.querySelector('.hero-content .animated-title');
    if (heroTitle) {
        heroTitle.addEventListener('mouseover', function() {
            this.classList.add('hover-effect');
        });
        
        heroTitle.addEventListener('mouseout', function() {
            this.classList.remove('hover-effect');
        });
    }
});
