/* Wallet Button Fix with Flames */
document.addEventListener('DOMContentLoaded', function() {
    // Update all "Get Started" buttons to "Get Hooked"
    const updateButtons = () => {
        const buttons = document.querySelectorAll('.cta-button, .plan-button, .platform-button, .wallet-connect-btn');
        
        buttons.forEach(button => {
            // Check if the button contains "Get Started" text
            if (button.textContent.includes('Get Started')) {
                // Replace text while preserving any icons
                const buttonHTML = button.innerHTML;
                const newHTML = buttonHTML.replace('Get Started', 'Get Hooked');
                button.innerHTML = newHTML;
            }
            
            // Add flame icon if not already present
            if (!button.querySelector('.flame-icon')) {
                const flameIcon = document.createElement('span');
                flameIcon.className = 'flame-icon';
                flameIcon.innerHTML = '🔥';
                button.prepend(flameIcon);
            }
            
            // Add wallet connection functionality
            button.addEventListener('click', connectWallet);
        });
    };
    
    // Connect to wallet function
    const connectWallet = async () => {
        try {
            // Check if Phantom wallet is available
            if (window.solana && window.solana.isPhantom) {
                // Show connecting message
                showNotification('Connecting to wallet...', 'info');
                
                // Connect to wallet
                const response = await window.solana.connect();
                const publicKey = response.publicKey.toString();
                
                // Store wallet info
                window.walletConnected = true;
                window.walletAddress = publicKey;
                
                // Show success message
                showNotification('Wallet connected: ' + publicKey.substring(0, 6) + '...' + publicKey.substring(publicKey.length - 4), 'success');
                
                // Trigger payment process
                startPaymentProcess();
            } else {
                // Phantom not installed
                showNotification('Phantom wallet not detected. Please install Phantom wallet extension.', 'error');
                
                // Open Phantom website in new tab
                window.open('https://phantom.app/', '_blank');
            }
        } catch (error) {
            console.error('Wallet connection error:', error);
            showNotification('Failed to connect wallet: ' + (error.message || 'Unknown error'), 'error');
        }
    };
    
    // Start payment process
    const startPaymentProcess = () => {
        // Show payment modal or redirect to payment section
        const paymentSection = document.getElementById('subscription-plans');
        if (paymentSection) {
            paymentSection.scrollIntoView({ behavior: 'smooth' });
            
            // Highlight the subscription options
            const plans = document.querySelectorAll('.plan');
            plans.forEach(plan => {
                plan.classList.add('highlight-plan');
                setTimeout(() => {
                    plan.classList.remove('highlight-plan');
                }, 2000);
            });
        }
    };
    
    // Show notification helper
    const showNotification = (message, type = 'info') => {
        // Remove existing notifications
        const existingNotification = document.querySelector('.wallet-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `wallet-notification ${type}`;
        notification.textContent = message;
        
        // Add to document
        document.body.appendChild(notification);
        
        // Show with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Auto hide after delay
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 500);
        }, 5000);
    };
    
    // Add CSS for notifications
    const addNotificationStyles = () => {
        const style = document.createElement('style');
        style.textContent = `
            .wallet-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 8px;
                color: white;
                font-weight: bold;
                z-index: 9999;
                transform: translateX(120%);
                transition: transform 0.3s ease;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
                max-width: 300px;
            }
            
            .wallet-notification.show {
                transform: translateX(0);
            }
            
            .wallet-notification.info {
                background-color: #3498db;
            }
            
            .wallet-notification.success {
                background-color: #2ecc71;
            }
            
            .wallet-notification.error {
                background-color: #e74c3c;
            }
            
            .highlight-plan {
                animation: highlight-pulse 1s 3;
            }
            
            @keyframes highlight-pulse {
                0% { box-shadow: 0 0 0 0 rgba(255,51,0,0.7); }
                70% { box-shadow: 0 0 0 15px rgba(255,51,0,0); }
                100% { box-shadow: 0 0 0 0 rgba(255,51,0,0); }
            }
            
            .flame-icon {
                margin-right: 8px;
                font-size: 1.2em;
                animation: flame-flicker 1.5s infinite alternate;
            }
            
            @keyframes flame-flicker {
                0% { opacity: 0.7; transform: scale(0.9); }
                100% { opacity: 1; transform: scale(1.1); }
            }
        `;
        document.head.appendChild(style);
    };
    
    // Initialize
    updateButtons();
    addNotificationStyles();
    
    // Re-run on dynamic content changes
    const observer = new MutationObserver(function(mutations) {
        updateButtons();
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
});
