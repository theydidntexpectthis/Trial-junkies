// Subscription Tracking Backend
// This file handles subscription verification, storage, and management

class SubscriptionManager {
    constructor() {
        this.dbConnection = null;
        this.initialized = false;
    }

    // Initialize the subscription manager
    async initialize() {
        try {
            // In a real implementation, this would connect to a database
            // For now, we'll use localStorage as a simple storage mechanism
            this.initialized = true;
            console.log('Subscription Manager initialized');
            return true;
        } catch (error) {
            console.error('Failed to initialize Subscription Manager:', error);
            return false;
        }
    }

    // Verify if a user has an active subscription
    async verifySubscription(walletAddress) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Get subscription data from storage
            const subscriptionData = localStorage.getItem('subscription_' + walletAddress);
            
            if (!subscriptionData) {
                return {
                    active: false,
                    message: 'No subscription found'
                };
            }
            
            const subscription = JSON.parse(subscriptionData);
            const now = new Date();
            const endDate = new Date(subscription.endDate);
            
            // Check if subscription is still valid
            if (endDate > now) {
                return {
                    active: true,
                    plan: subscription.plan,
                    endDate: subscription.endDate,
                    daysLeft: Math.ceil((endDate - now) / (1000 * 60 * 60 * 24)),
                    message: 'Subscription active'
                };
            } else {
                return {
                    active: false,
                    expired: true,
                    lastPlan: subscription.plan,
                    message: 'Subscription expired'
                };
            }
        } catch (error) {
            console.error('Error verifying subscription:', error);
            return {
                active: false,
                error: true,
                message: 'Error verifying subscription'
            };
        }
    }

    // Create or update a subscription
    async createSubscription(walletAddress, plan, price) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Calculate end date (30 days from now)
            const startDate = new Date();
            const endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + 30);
            
            // Create subscription object
            const subscription = {
                walletAddress,
                plan,
                price,
                startDate: startDate.toISOString(),
                endDate: endDate.toISOString(),
                status: 'active',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };
            
            // Save to storage
            localStorage.setItem('subscription_' + walletAddress, JSON.stringify(subscription));
            
            // Also update the global subscription for the current session
            localStorage.setItem('subscription', JSON.stringify(subscription));
            
            return {
                success: true,
                subscription
            };
        } catch (error) {
            console.error('Error creating subscription:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Extend an existing subscription
    async extendSubscription(walletAddress, additionalDays = 30) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Get existing subscription
            const subscriptionData = localStorage.getItem('subscription_' + walletAddress);
            
            if (!subscriptionData) {
                return {
                    success: false,
                    message: 'No subscription found to extend'
                };
            }
            
            const subscription = JSON.parse(subscriptionData);
            
            // Calculate new end date
            let endDate = new Date(subscription.endDate);
            if (endDate < new Date()) {
                // If subscription has expired, start from today
                endDate = new Date();
            }
            endDate.setDate(endDate.getDate() + additionalDays);
            
            // Update subscription
            subscription.endDate = endDate.toISOString();
            subscription.updatedAt = new Date().toISOString();
            
            // Save updated subscription
            localStorage.setItem('subscription_' + walletAddress, JSON.stringify(subscription));
            
            // Also update the global subscription for the current session
            localStorage.setItem('subscription', JSON.stringify(subscription));
            
            return {
                success: true,
                subscription
            };
        } catch (error) {
            console.error('Error extending subscription:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Cancel a subscription
    async cancelSubscription(walletAddress) {
        if (!this.initialized) await this.initialize();
        
        try {
            // Get existing subscription
            const subscriptionData = localStorage.getItem('subscription_' + walletAddress);
            
            if (!subscriptionData) {
                return {
                    success: false,
                    message: 'No subscription found to cancel'
                };
            }
            
            const subscription = JSON.parse(subscriptionData);
            
            // Update subscription status
            subscription.status = 'cancelled';
            subscription.updatedAt = new Date().toISOString();
            
            // Save updated subscription
            localStorage.setItem('subscription_' + walletAddress, JSON.stringify(subscription));
            
            // Also update the global subscription for the current session
            localStorage.setItem('subscription', JSON.stringify(subscription));
            
            return {
                success: true,
                subscription
            };
        } catch (error) {
            console.error('Error cancelling subscription:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Get all subscriptions for reporting
    async getAllSubscriptions() {
        if (!this.initialized) await this.initialize();
        
        try {
            const subscriptions = [];
            
            // In a real implementation, this would query the database
            // For localStorage, we need to iterate through all keys
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith('subscription_')) {
                    const subscription = JSON.parse(localStorage.getItem(key));
                    subscriptions.push(subscription);
                }
            }
            
            return {
                success: true,
                subscriptions
            };
        } catch (error) {
            console.error('Error getting all subscriptions:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
}

// Export the subscription manager
window.SubscriptionManager = new SubscriptionManager();
