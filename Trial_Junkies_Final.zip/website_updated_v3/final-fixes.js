// Wallet Button Functionality Fix
document.addEventListener('DOMContentLoaded', function() {
    // Find all wallet buttons
    const walletButtons = document.querySelectorAll('.phantom-wallet-btn, .connect-wallet-btn, .wallet-connect-btn');
    
    // Add event listeners to all wallet buttons
    walletButtons.forEach(button => {
        // Remove any existing images inside the buttons
        const images = button.querySelectorAll('img');
        images.forEach(img => img.remove());
        
        // Add click event listener
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Simulate wallet connection
            console.log('Connecting to Phantom wallet...');
            
            // Show connection attempt
            alert('Connecting to Phantom wallet...');
            
            // You would typically call the Phantom wallet API here
            // For demonstration purposes, we're just showing an alert
        });
    });
    
    // Remove any reward sections
    const rewardElements = document.querySelectorAll('#reward-tracker, .reward-tracker-container, .reward-status, .reward-bundles, .your-trial-rewards, .trial-junkie-status');
    rewardElements.forEach(el => {
        if (el) el.style.display = 'none';
    });
    
    // Remove white boxes under not connected
    const whiteBoxes = document.querySelectorAll('.not-connected-box, .white-box-container, .not-connected, .wallet-status-box');
    whiteBoxes.forEach(box => {
        if (box) box.style.display = 'none';
    });
    
    // Fix header bug square
    const headerBugs = document.querySelectorAll('.header-bug-square, .header-bug, .nav-bug');
    headerBugs.forEach(bug => {
        if (bug) bug.style.display = 'none';
    });
    
    // Replace logo with red skull
    const logoElements = document.querySelectorAll('.logo, .logo-img, .site-logo');
    logoElements.forEach(logo => {
        if (logo) {
            // Clear any existing content
            logo.innerHTML = '';
            
            // Create new image element for red skull logo
            const redSkullLogo = document.createElement('img');
            redSkullLogo.src = './assets/new_images/red-skull-logo.png';
            redSkullLogo.alt = 'Trial Junkies Logo';
            redSkullLogo.classList.add('red-skull-logo');
            
            // Append the new logo
            logo.appendChild(redSkullLogo);
            
            // Ensure transparent background
            logo.style.backgroundColor = 'transparent';
        }
    });
    
    // Check all images are displaying properly
    const allImages = document.querySelectorAll('img');
    allImages.forEach(img => {
        // Ensure proper styling
        img.style.maxWidth = '100%';
        img.style.height = 'auto';
        img.style.objectFit = 'contain';
        
        // Log any broken images
        img.onerror = function() {
            console.error('Failed to load image:', img.src);
        };
    });
});
